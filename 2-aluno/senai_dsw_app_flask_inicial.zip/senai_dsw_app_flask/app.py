from flask import Flask, render_template
from routes.routes import configurar_rotas

app = Flask(__name__)

app.config['SECRET_KEY'] = 'chave_secreta'

# Configurando as rotas
configurar_rotas(app)

if __name__ == '__main__':
    app.run(debug=True)
