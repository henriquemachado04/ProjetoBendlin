document.addEventListener('DOMContentLoaded', function() {
    const menuItems = document.querySelectorAll('.menu-item');

	menuItems.forEach(item => {
		item.addEventListener('click', function(event) {
			alert('Clicado');
			const submenu = this.querySelector('.submenu');

			if (submenu) {
				alert('Submenu encontrado!');
				submenu.style.display = submenu.style.display === 'block' ? 'none' : 'block';
			} else {
				alert('Submenu não encontrado');
			}
		});
	});

    // Fecha submenus ao clicar fora do menu
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.menu-item')) {
            document.querySelectorAll('.submenu').forEach(menu => {
                menu.style.display = 'none';
            });
        }
    });
});
